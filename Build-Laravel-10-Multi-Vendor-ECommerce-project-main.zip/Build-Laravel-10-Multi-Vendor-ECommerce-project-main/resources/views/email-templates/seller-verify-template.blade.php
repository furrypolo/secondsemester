<p>Dear {{ $seller_name }}</p>
<p>
    We are received this email to verify Laravel Seller account associated with {{ $seller_email }} <br>
    You can verify your account by clicking on below link: <br>
    <a href="{{ $action_link }}">Verify Account</a>
</p>