<?php return array (
  'admin-categories-subcategories-list' => 'App\\Http\\Livewire\\AdminCategoriesSubcategoriesList',
  'admin-profile-tabs' => 'App\\Http\\Livewire\\AdminProfileTabs',
  'admin-seller-header-profile-info' => 'App\\Http\\Livewire\\AdminSellerHeaderProfileInfo',
  'admin-settings' => 'App\\Http\\Livewire\\AdminSettings',
);