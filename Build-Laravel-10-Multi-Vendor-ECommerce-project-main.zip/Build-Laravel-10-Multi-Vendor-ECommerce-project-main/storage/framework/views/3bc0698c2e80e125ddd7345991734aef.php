<?php $__env->startSection('pageTitle', isset($pageTitle) ? $pageTitle : 'Page title'); ?>
<?php $__env->startSection('content'); ?>
 --- Content here ---
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.pages-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\repos\secondsemester\Build-Laravel-10-Multi-Vendor-ECommerce-project-main\resources\views/example-frontend.blade.php ENDPATH**/ ?>