<?php $__env->startSection('pageTitle', isset($pageTitle) ? $pageTitle : 'Home'); ?>
<?php $__env->startSection('content'); ?>
  content here...
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout.pages-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravell\Build-Laravel-10-Multi-Vendor-ECommerce-project-main\resources\views/back/pages/admin/home.blade.php ENDPATH**/ ?>