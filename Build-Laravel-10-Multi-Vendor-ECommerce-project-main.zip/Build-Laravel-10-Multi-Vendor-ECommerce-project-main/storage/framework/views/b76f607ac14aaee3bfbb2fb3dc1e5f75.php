<div class="mobile-menu d-md-none d-block mobile-cart">
    <ul>
        <li class="active">
            <a href="index.html">
                <i class="icon-copy dw dw-home icli"></i>
                <span>Home</span>
            </a>
        </li>

        <li class="mobile-category">
            <a href="javascript:void(0)">
                <i class="icon-copy dw dw-list3 icli js-link"></i>
                <span>Category</span>
            </a>
        </li>

        <li>
            <a href="search.html" class="search-box">
                <i class="icon-copy dw dw-search icli"></i>
                <span>Search</span>
            </a>
        </li>

        <li>
            <a href="wishlist.html" class="notifi-wishlist">
                <i class="icon-copy dw dw-heart icli"></i>
                <span>Wishlist</span>
            </a>
        </li>

        <li>
            <a href="cart.html">
                <i class="icon-copy dw dw-shopping-cart1 icli fly-cate"></i>
                <span>Cart</span>
            </a>
        </li>
    </ul>
</div><?php /**PATH C:\Users\Lenovo\repos\secondsemester\Build-Laravel-10-Multi-Vendor-ECommerce-project-main\resources\views/front/layout/inc/mobile-menu.blade.php ENDPATH**/ ?>