#535230080_Georgia Sugisandhea_Kelas C
import numpy as np

a=np.array([[1,2,3], [4,5,6], [7,8,9]])
print("Hasil penjumlahan baris kedua dan baris ketiga", a[1,:]+a[2,:])