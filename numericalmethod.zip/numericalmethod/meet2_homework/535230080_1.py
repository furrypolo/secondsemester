#535230080_Georgia Sugisandhea_Kelas C
import numpy as np

a=np.array([0,1,2,3,4,5,6,7,8,9])
idx_bool=(a%2==0)
print("Elemen yang habis dibagi 2:", a[idx_bool])