// package strukdat;

// import java.util.*;

// public class Vertex<T> {
//     private final T data;
//     private boolean visited;
//     private List<Vertex<T>> neighbors = new LinkedList<>();
// }
