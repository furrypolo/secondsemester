import strukdat.HuffmanNode;
import strukdat.Heap;
import strukdat.TheArrayList;

public class HuffmanCoding {
    public static void main(String[] args){
        char[] charArray = {'E', 'T', 'N', 'I', 'S'};
        int[] charfreq = {29, 10, 9, 5, 4};

        Heap<Integer, HuffmanNode> pq = new Heap<Integer,HuffmanNode>(charArray.length,false);
        HuffmanNode x = null;
        HuffmanNode y = null;
        int i;
        for(i=0; i<charArray.length; i++){
            HuffmanNode first = new HuffmanNode(charfreq[i], charArray[i], x, y);
            pq.insert(charfreq[i], first);
            pq.sort();
        }
        HuffmanNode root = null;
        int sum;
        HuffmanNode t;
        char val;

        TheArrayList<String> fin; 
        System.out.println("------------------");
        System.out.println("Huruf | Huffman code");
        System.out.println("------------------");
        for(int b=0; b<=charfreq.length; b++){
            sum = pq.getKey(pq.first());
            t = pq.getData(pq.first());
            pq.removeFirst();
            val = t.getValue();
            root = new HuffmanNode(sum, val, x, y);
            fin = root.getHuffmanCodes(root, charfreq.length);
            val = root.getValue();
            System.out.print(val + " | " );
            fin.cetakList();
            System.out.println("");
        }
        System.out.println("------------------");
    }
}
