import strukdat.Heap;
import java.util.Random;

public class App {
    public static void main(String[] args) throws Exception {
        long start = System.currentTimeMillis();
        Random random = new Random();
        String[] data = {"Andree", "Leana", "Faviola", "Loyce", "Quincy", "Forshe", "Gourmee", "Morkami", "Horfei", "Evangeline"};
        Heap<Integer,String>heap=new Heap<Integer,String>(80000,false);
        for(int i=0;i<80000;i++)
            //Memasukkan random integer kepada heap dan juga nama data yang berbeda dari 10 nama data yang telah dimasukkan
            heap.add(random.nextInt(), data[i%10]);
        heap.buildHeap();
        heap.sort();
        long finish = System.currentTimeMillis();
        long time=finish-start;
        System.out.println("Waktu yang digunakan = " + time);
    }
}
