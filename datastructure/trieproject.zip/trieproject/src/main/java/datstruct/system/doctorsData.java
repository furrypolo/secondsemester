package datstruct.system;

public class doctorsData {
    String disease;
    String name;

    public doctorsData(String disease, String name){
        this.disease = disease;
        this.name = name;
    }
}
