package datstruct.system;

public class Node {
    Node links[] = new Node[26];
    boolean flag = false;

    public Node() {
        
    }

    boolean containsKey(char ch){
        return (links[ch-'a'] != null);
    }

    Node get(char ch) {
        return links[ch-'a'];
    }

    void put(char ch, Node node){
        links[ch-'a'] = node;
    }

    void setEnd(){
        flag = true;
    }

    boolean isEnd(){
        return flag;
    }
}
